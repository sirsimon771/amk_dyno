# amk_dyno
an application to control an amk inverter through a usb to can adapter to control an amk pmsm
